The helper function contains the following:

def take(n, iterable): This functions was used to initial data exploration. It returns the n elements in a list.